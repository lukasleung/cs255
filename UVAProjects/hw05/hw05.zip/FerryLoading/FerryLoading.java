import java.util.Arrays;
import java.util.Scanner;

/**
 * UVA 10261 Ferry Loading Timelimit = 3.000 seconds
 * Completed testing in: 0. seconds on
 * To Run type:
 *      javac FerryLoading
 *      java FerryLoading < pathTo/input.txt > printToThis.txt
 * @author Lukas Leung
 * @version 3.0
 */
public class FerryLoading {
    public static void printS(boolean[][] arr) {
        for (int r = 0; r < arr.length; r++) {
            for (int c = 0; c < arr[r].length; c++) {
                if (arr[r][c]) {
                    System.out.println("\tarr[" + r + "][" + c + "]");
                }
            }
            // System.out.println();
        }
    }
    public static void printD(boolean[][] arr, int curRow) {
        for (int r = 0; r < arr.length; r++) {

            for (int c = 0; c < arr[r].length; c++) {
                if (arr[r][c]) {
                    if (curRow == r) { System.out.print("*"); }
                    System.out.println("\tarr[" + r + "][" + c + "]");
                }
            }
            System.out.println();
        }
    }
    public static void print1D(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            if (i != 0 && (i % 20 == 0)) {
                System.out.println();
            }
            System.out.printf("% 5d ", arr[i]);
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int numCases = Integer.parseInt(in.nextLine());

        for (int caseNum = 0; caseNum < numCases; caseNum++) {
            in.nextLine(); // blank line before start of each case
            final int LENGTH = Integer.parseInt(in.nextLine()) * 100;

            // only use 1 row at a time so take out after each use
            boolean[][] dynamic = new boolean[2][LENGTH + 1];
            dynamic[0][0] = true; // always possible to have 0 length

            boolean[][] solutions = new boolean[202][LENGTH + 1];
            int[] carLen = new int[202];
            System.out.println("_____________________\n\tdynamic\n");
            printD(dynamic, 0);
            System.out.println("\n\n\n_____________________\n\tsolutions\n");
            printS(solutions);
            System.out.println("\n\n\n_____________________\n   carLen Before");
            print1D(carLen);

            boolean done = false;
            int curRow = 0,
                invRow,
                curCar = 0,  // index of the current car
                     n = 0,  // number of cars loaded
                sumLen = 0,  // sum of all lengths
               lastLen = 0;  // length at port side

            while (true) {
                int currentLen = Integer.parseInt(in.nextLine());
                if (currentLen == 0) { break; } // end of this case
                if (done) { continue; } // ignore the following cars

                invRow = curRow;
                curRow = (curRow + 1) % 2;
                curCar++;
                carLen[curCar] = currentLen;
                sumLen += currentLen;

                Arrays.fill(dynamic[curRow], false); // clean the current row
                boolean canLoad = false;
                for (int len = 0; len <= LENGTH; len++) {
                    if (!dynamic[invRow][len]) { continue; }

                    // put car on starboard side?
                    int pos = len + currentLen;
                    if ((pos <= LENGTH) && (sumLen - pos <= LENGTH)) {
                        dynamic[curRow][pos] = true;
                        solutions[curCar][pos] = false; // false for starboard
                        lastLen = len + currentLen;
                        canLoad = true;
                    }

                    // put car on port side?
                    if (sumLen - len <= LENGTH && len <= LENGTH) {
                        dynamic[curRow][len] = true;
                        solutions[curCar][len] = true;  // true for port side
                        lastLen = len;
                        canLoad = true;
                    }
                }
                if (!canLoad) { done = true; }
                else {
                    n++;
                    System.out.println("Round " + n +": " + currentLen);
                    System.out.println("  Solutions");
                    printS(solutions);
                    System.out.println("  Dynamic");
                    printD(dynamic, curRow);
                }
            }
            System.out.println("_____________________\n\tdynamic\n");
            printD(dynamic, curRow);
            System.out.println("\n\n\n_____________________\n\tsolutions\n");
            printS(solutions);

            System.out.println("\n\n\n_____________________\n   carLen After\n");
            print1D(carLen);

            boolean[] backtrack = new boolean[n+1];
            // iterate in the reverse direction, from last car to the first
            for (int i = n; i > 0; i--) {
                // if last car was port
                if (!solutions[i][lastLen]) {
                    lastLen -= carLen[i];  // decrease starboard side length
                    backtrack[i] = false;  // record starboard side
                } else if (solutions[i][lastLen]) {
                    backtrack[i] = true;
                }
            }

            // print everything out
            System.out.println(n);
            for (int i = 1; i <= n; i++) {
                if (backtrack[i]) {
                    System.out.println("port");
                } else if (!backtrack[i]) {
                    System.out.println("starboard");
                }
            }
            if (caseNum < numCases - 1) { System.out.println(); }
        }
    }
}