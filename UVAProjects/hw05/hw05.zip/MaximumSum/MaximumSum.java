import java.util.Scanner;

/**
 * UVA 108 Maximum Sum Timelimit = 3.000 seconds
 * Completed testing in: 0.152 seconds on 2016-03-19 19:51:07
 * To Run type:
 *      javac MaximumSum
 *      java MaximumSum < pathTo/input.txt > printToThis.txt
 * @author Lukas Leung
 * @version 2.0
 */
public class MaximumSum {
    public static int maxSum(int[][] colPrefix, int N) {
        int sum, colSum, max = Integer.MIN_VALUE;
        // visit every element
        for (int row = 1; row <= N; row++) {
            for (int rowOff = 0; rowOff <= (N - row); rowOff++) {
                System.out.println("row: " + (row + rowOff));
                // going to next col
                sum = 0;
                for (int col = 0; col < N; col++) {
                    colSum = colPrefix[row + rowOff][col] - colPrefix[rowOff][col];


                    System.out.println("\t| col[" + (row + rowOff) + "][" + col +
                            "] - col[" + rowOff + "][" + col + "]");
                    System.out.println("\t| => " + colPrefix[row + rowOff][col] +
                            " - " +  colPrefix[rowOff][col] + " = " + colSum);
                    // make sure that it is not 0 at this point
                    if (sum >= 0) {
                        sum += colSum;
                    } else {
                        sum = colSum;
                    }
                    if (sum > max) {
                        max = sum;
                    }
                    System.out.println("\t|\t| sum = " + sum +
                            "\n\t|\t| max = " + max);
                }
            }
        }
        return max;
    }
    public static void printMap(int[][] map) {
        System.out.println("________________");
        for (int r = 0; r < map.length; r++) {
            for (int c = 0; c < map[r].length; c++) {
                System.out.print(map[r][c] + " ");
            }
            System.out.println();
        }
        System.out.println("________________");
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while (in.hasNext()) {
            int N = in.nextInt();
            int[][] map = new int[N+1][N+1];
            int[][] oMap = new int[N+1][N+1];
            for (int r = 1; r <= N; r++) {
                for (int c = 0; c < N; c++) {
                    int val = in.nextInt();
                    oMap[r][c+1] = val;
                    map[r][c] = val + map[r - 1][c];
//                    map[r][j] = in.nextInt() + map[r - 1][c];
                }
            }
            printMap(oMap);
            printMap(map);
            System.out.println(maxSum(map, N));
        }
    }
}